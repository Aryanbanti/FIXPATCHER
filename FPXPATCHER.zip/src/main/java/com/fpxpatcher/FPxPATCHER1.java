package com.fpxpatcher;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

@Mod(modid = "fpxpatcher", name = "FPxPATCHER1", version = "1.0.2")
public class FPxPATCHER1 {
    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        System.out.println("FPxPATCHER1 initialized!");
    }
}
